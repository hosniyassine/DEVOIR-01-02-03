package com.hosni.test;

import com.hosni.dao.ClientDAO;
import com.hosni.entities.Client;
import com.hosni.util.JPAUtil;

import java.util.List;

public class TestClient {

    public static void main(String[] args) {

        ClientDAO dao = new ClientDAO();

        // Ajouter quelques clients
        dao.ajouter(new Client("Ali", "Tunis"));
        dao.ajouter(new Client("Med", "Sfax"));
        dao.ajouter(new Client("Sara", "Sousse"));

        // Lister tous les clients
        System.out.println("=== Tous les clients ===");
        List<Client> tous = dao.listerTous();
        for (Client c : tous) {
            System.out.println(c);
        }

        // Rechercher par nom
        System.out.println("=== Clients dont le nom contient 'a' ===");
        List<Client> filtres = dao.listerParNom("a");
        for (Client c : filtres) {
            System.out.println(c);
        }

        JPAUtil.close();
    }
}

