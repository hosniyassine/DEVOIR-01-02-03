package com.hosni.dao;

import com.hosni.entities.Client;
import com.hosni.util.JPAUtil;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import java.util.List;

public class ClientDAO {

    private final EntityManager entityManager;

    public ClientDAO() {
        this.entityManager = JPAUtil.getEntityManager("MonProjetJPA");
    }

    public void ajouter(Client c) {
        EntityTransaction tx = entityManager.getTransaction();
        tx.begin();
        entityManager.persist(c);
        tx.commit();
    }

    public void modifier(Client c) {
        EntityTransaction tx = entityManager.getTransaction();
        tx.begin();
        entityManager.merge(c);
        tx.commit();
    }

    public void supprimer(Client c) {
        EntityTransaction tx = entityManager.getTransaction();
        tx.begin();
        c = entityManager.merge(c);
        entityManager.remove(c);
        tx.commit();
    }

    public Client consulter(Object id) {
        return entityManager.find(Client.class, id);
    }

    public List<Client> listerTous() {
        TypedQuery<Client> query =
                entityManager.createQuery("SELECT c FROM Client c", Client.class);
        return query.getResultList();
    }

    public List<Client> listerParNom(String pNom) {
        TypedQuery<Client> query =
                entityManager.createQuery("SELECT c FROM Client c WHERE c.nom LIKE :pNom", Client.class);
        query.setParameter("pNom", "%" + pNom + "%");
        return query.getResultList();
    }
}

