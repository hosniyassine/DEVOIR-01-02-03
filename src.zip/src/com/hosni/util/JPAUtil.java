package com.hosni.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtil {

    private static EntityManagerFactory factory;
    private static EntityManager entityManager;

    private JPAUtil() {
        // utilitaire
    }

    public static EntityManager getEntityManager(String persistUnit) {
        if (entityManager == null) {
            factory = Persistence.createEntityManagerFactory(persistUnit);
            entityManager = factory.createEntityManager();
        }
        return entityManager;
    }

    public static void close() {
        if (entityManager != null) {
            entityManager.close();
            entityManager = null;
        }
        if (factory != null) {
            factory.close();
            factory = null;
        }
    }
}

