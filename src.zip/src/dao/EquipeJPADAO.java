package dao;

import model.EquipeJPA;
import util.JPAUtil;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import java.util.List;

public class EquipeJPADAO {

    private final EntityManager entityManager;

    public EquipeJPADAO() {
        this.entityManager = JPAUtil.getEntityManager("GestionEquipeJoueurJPA");
    }

    public void ajouter(EquipeJPA equipe) {
        EntityTransaction tx = entityManager.getTransaction();
        tx.begin();
        entityManager.persist(equipe);
        tx.commit();
    }

    public void modifier(EquipeJPA equipe) {
        EntityTransaction tx = entityManager.getTransaction();
        tx.begin();
        entityManager.merge(equipe);
        tx.commit();
    }

    public void supprimer(EquipeJPA equipe) {
        EntityTransaction tx = entityManager.getTransaction();
        tx.begin();
        equipe = entityManager.merge(equipe);
        entityManager.remove(equipe);
        tx.commit();
    }

    public EquipeJPA consulter(Object id) {
        return entityManager.find(EquipeJPA.class, id);
    }

    public List<EquipeJPA> listerTous() {
        TypedQuery<EquipeJPA> query =
                entityManager.createQuery("SELECT e FROM EquipeJPA e ORDER BY e.idEquipe", EquipeJPA.class);
        return query.getResultList();
    }

    public List<EquipeJPA> listerParNom(String pNom) {
        TypedQuery<EquipeJPA> query =
                entityManager.createQuery(
                        "SELECT e FROM EquipeJPA e WHERE e.nomEquipe LIKE :pNom ORDER BY e.idEquipe",
                        EquipeJPA.class);
        query.setParameter("pNom", "%" + pNom + "%");
        return query.getResultList();
    }
}

