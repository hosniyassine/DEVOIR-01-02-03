package dao;

import model.Equipe;

import java.sql.SQLException;
import java.util.List;

public interface EquipeInterface {

    Equipe ajouterEquipe(Equipe equipe) throws SQLException;

    List<Equipe> listerEquipes() throws SQLException;

    List<Equipe> trouverParNom(String nom) throws SQLException;

    void supprimerEquipe(int id) throws SQLException;

    Equipe trouverParId(int idEquipe) throws SQLException;

    void modifierEquipe(Equipe equipe) throws SQLException;
}