package dao;

import model.Equipe;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EquipeDAO implements EquipeInterface {


    public Equipe ajouterEquipe(Equipe equipe) throws SQLException {
        String sql = "INSERT INTO Equipe (nomEquipe) VALUES (?)";
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, equipe.getNomEquipe());
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                return new Equipe(id, equipe.getNomEquipe());
            }
            return equipe;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    public List<Equipe> listerEquipes() throws SQLException {
        String sql = "SELECT idEquipe, nomEquipe FROM Equipe ORDER BY idEquipe";
        List<Equipe> liste = new ArrayList<>();
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs   = stmt.executeQuery(sql);
            while (rs.next()) {
                liste.add(new Equipe(
                        rs.getInt("idEquipe"),
                        rs.getString("nomEquipe")
                ));
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
        return liste;
    }

    
    public List<Equipe> trouverParNom(String nom) throws SQLException {
        String sql = "SELECT idEquipe, nomEquipe FROM Equipe WHERE nomEquipe LIKE ? ORDER BY idEquipe";
        List<Equipe> liste = new ArrayList<>();
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + nom + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                liste.add(new Equipe(rs.getInt("idEquipe"), rs.getString("nomEquipe")));
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
        return liste;
    }

    public void supprimerEquipe(int id) throws SQLException {
        String sql = "DELETE FROM Equipe WHERE idEquipe = ?";
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    public void modifierEquipe(Equipe equipe) throws SQLException {
        String sql = "UPDATE Equipe SET nomEquipe = ? WHERE idEquipe = ?";
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, equipe.getNomEquipe());
            ps.setInt(2, equipe.getIdEquipe());
            ps.executeUpdate();
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    public Equipe trouverParId(int idEquipe) throws SQLException {
        String sql = "SELECT idEquipe, nomEquipe FROM Equipe WHERE idEquipe = ?";
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idEquipe);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Equipe(
                        rs.getInt("idEquipe"),
                        rs.getString("nomEquipe")
                );
            }
            return null;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
}
