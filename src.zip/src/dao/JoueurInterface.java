package dao;

import model.Joueur;

import java.sql.SQLException;
import java.util.List;

public interface JoueurInterface {

    Joueur ajouterJoueur(Joueur joueur) throws SQLException;

    List<Joueur> listerJoueurs() throws SQLException;



    List<Joueur> trouverParNom(String nom) throws SQLException;

    Joueur trouverParId(int idJoueur) throws SQLException;

    void modifierJoueur(Joueur joueur) throws SQLException;

    void supprimerJoueur(int id) throws SQLException;
}