package dao;

import model.Joueur;
import util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JoueurDAO implements JoueurInterface {


    public Joueur ajouterJoueur(Joueur joueur) throws SQLException {
        String sql = "INSERT INTO Joueur (nomJoueur, poste, idEquipe) VALUES (?, ?, ?)";
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, joueur.getNomJoueur());
            ps.setString(2, joueur.getPoste());
            ps.setInt(3,    joueur.getIdEquipe());
            ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int id = rs.getInt(1);
                return new Joueur(id, joueur.getNomJoueur(), joueur.getPoste(), joueur.getIdEquipe());
            }
            return joueur;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }


    public List<Joueur> listerJoueurs() throws SQLException {
        String sql = "SELECT j.idJoueur, j.nomJoueur, j.poste, j.idEquipe, e.nomEquipe "
                   + "FROM Joueur j "
                   + "JOIN Equipe e ON j.idEquipe = e.idEquipe "
                   + "ORDER BY j.idJoueur";
        List<Joueur> liste = new ArrayList<>();
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            Statement stmt = conn.createStatement();
            ResultSet rs   = stmt.executeQuery(sql);
            while (rs.next()) {
                Joueur j = new Joueur(
                        rs.getInt("idJoueur"),
                        rs.getString("nomJoueur"),
                        rs.getString("poste"),
                        rs.getInt("idEquipe")
                );
                j.setNomEquipe(rs.getString("nomEquipe"));
                liste.add(j);
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
        return liste;
    }





    public List<Joueur> trouverParNom(String nom) throws SQLException {
        String sql = "SELECT j.idJoueur, j.nomJoueur, j.poste, j.idEquipe, e.nomEquipe "
                   + "FROM Joueur j "
                   + "JOIN Equipe e ON j.idEquipe = e.idEquipe "
                   + "WHERE j.nomJoueur LIKE ? "
                   + "ORDER BY j.idJoueur";
        List<Joueur> liste = new ArrayList<>();
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, "%" + nom + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Joueur j = new Joueur(
                        rs.getInt("idJoueur"),
                        rs.getString("nomJoueur"),
                        rs.getString("poste"),
                        rs.getInt("idEquipe")
                );
                j.setNomEquipe(rs.getString("nomEquipe"));
                liste.add(j);
            }
        } finally {
            DBConnection.closeConnection(conn);
        }
        return liste;

    }

    public Joueur trouverParId(int idJoueur) throws SQLException {
        String sql = "SELECT j.idJoueur, j.nomJoueur, j.poste, j.idEquipe, e.nomEquipe "
                   + "FROM Joueur j "
                   + "JOIN Equipe e ON j.idEquipe = e.idEquipe "
                   + "WHERE j.idJoueur = ?";
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, idJoueur);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Joueur j = new Joueur(
                        rs.getInt("idJoueur"),
                        rs.getString("nomJoueur"),
                        rs.getString("poste"),
                        rs.getInt("idEquipe")
                );
                j.setNomEquipe(rs.getString("nomEquipe"));
                return j;
            }
            return null;
        } finally {
            DBConnection.closeConnection(conn);
        }
    }

    public void modifierJoueur(Joueur joueur) throws SQLException {
        String sql = "UPDATE Joueur SET nomJoueur = ?, poste = ?, idEquipe = ? WHERE idJoueur = ?";
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, joueur.getNomJoueur());
            ps.setString(2, joueur.getPoste());
            ps.setInt(3,    joueur.getIdEquipe());
            ps.setInt(4,    joueur.getIdJoueur());
            ps.executeUpdate();
        } finally {
            DBConnection.closeConnection(conn);
        }
    }


    public void supprimerJoueur(int id) throws SQLException {
        String sql = "DELETE FROM Joueur WHERE idJoueur = ?";
        Connection conn = null;
        try {
            conn = DBConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        } finally {
            DBConnection.closeConnection(conn);
        }
    }
}
