package dao;

import model.EquipeJPA;
import model.JoueurJPA;
import util.JPAUtil;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;
import java.util.List;

public class JoueurJPADAO {

    private final EntityManager entityManager;

    public JoueurJPADAO() {
        this.entityManager = JPAUtil.getEntityManager("GestionEquipeJoueurJPA");
    }

    public void ajouter(JoueurJPA joueur) {
        EntityTransaction tx = entityManager.getTransaction();
        tx.begin();
        entityManager.persist(joueur);
        tx.commit();
    }

    public void modifier(JoueurJPA joueur) {
        EntityTransaction tx = entityManager.getTransaction();
        tx.begin();
        entityManager.merge(joueur);
        tx.commit();
    }

    public void supprimer(JoueurJPA joueur) {
        EntityTransaction tx = entityManager.getTransaction();
        tx.begin();
        joueur = entityManager.merge(joueur);
        entityManager.remove(joueur);
        tx.commit();
    }

    public JoueurJPA consulter(Object id) {
        return entityManager.find(JoueurJPA.class, id);
    }

    public List<JoueurJPA> listerTous() {
        TypedQuery<JoueurJPA> query =
                entityManager.createQuery(
                        "SELECT j FROM JoueurJPA j JOIN FETCH j.equipe ORDER BY j.idJoueur",
                        JoueurJPA.class);
        return query.getResultList();
    }

    public List<JoueurJPA> listerParNom(String pNom) {
        TypedQuery<JoueurJPA> query =
                entityManager.createQuery(
                        "SELECT j FROM JoueurJPA j JOIN FETCH j.equipe " +
                                "WHERE j.nomJoueur LIKE :pNom ORDER BY j.idJoueur",
                        JoueurJPA.class);
        query.setParameter("pNom", "%" + pNom + "%");
        return query.getResultList();
    }

    public List<JoueurJPA> listerParEquipe(EquipeJPA equipe) {
        TypedQuery<JoueurJPA> query =
                entityManager.createQuery(
                        "SELECT j FROM JoueurJPA j JOIN FETCH j.equipe " +
                                "WHERE j.equipe = :equipe ORDER BY j.idJoueur",
                        JoueurJPA.class);
        query.setParameter("equipe", equipe);
        return query.getResultList();
    }
}

