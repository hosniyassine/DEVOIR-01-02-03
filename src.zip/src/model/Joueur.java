package model;

public class Joueur {

    private int    idJoueur;
    private String nomJoueur;
    private String poste;
    private int    idEquipe;

    // Pour l'affichage du nom de l'équipe dans les vues
    private String nomEquipe;

    public Joueur() {}

    public Joueur(int idJoueur, String nomJoueur, String poste, int idEquipe) {
        this.idJoueur  = idJoueur;
        this.nomJoueur = nomJoueur;
        this.poste     = poste;
        this.idEquipe  = idEquipe;
    }

    public Joueur(String nomJoueur, String poste, int idEquipe) {
        this.nomJoueur = nomJoueur;
        this.poste     = poste;
        this.idEquipe  = idEquipe;
    }

    // Getters & Setters
    public int getIdJoueur() { return idJoueur; }
    public void setIdJoueur(int idJoueur) { this.idJoueur = idJoueur; }

    public String getNomJoueur() { return nomJoueur; }
    public void setNomJoueur(String nomJoueur) { this.nomJoueur = nomJoueur; }

    public String getPoste() { return poste; }
    public void setPoste(String poste) { this.poste = poste; }

    public int getIdEquipe() { return idEquipe; }
    public void setIdEquipe(int idEquipe) { this.idEquipe = idEquipe; }

    public String getNomEquipe() { return nomEquipe; }
    public void setNomEquipe(String nomEquipe) { this.nomEquipe = nomEquipe; }

    @Override
    public String toString() {
        return "Joueur{idJoueur=" + idJoueur
                + ", nomJoueur='" + nomJoueur + "'"
                + ", poste='" + poste + "'"
                + ", idEquipe=" + idEquipe + "}";
    }
}
