package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class JoueurJPA {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idJoueur;

    private String nomJoueur;
    private String poste;

    @ManyToOne
    @JoinColumn(name = "idEquipe", nullable = false)
    private EquipeJPA equipe;

    public JoueurJPA() {
    }

    public JoueurJPA(String nomJoueur, String poste, EquipeJPA equipe) {
        this.nomJoueur = nomJoueur;
        this.poste = poste;
        this.equipe = equipe;
    }

    public JoueurJPA(int idJoueur, String nomJoueur, String poste, EquipeJPA equipe) {
        this.idJoueur = idJoueur;
        this.nomJoueur = nomJoueur;
        this.poste = poste;
        this.equipe = equipe;
    }

    public int getIdJoueur() {
        return idJoueur;
    }

    public void setIdJoueur(int idJoueur) {
        this.idJoueur = idJoueur;
    }

    public String getNomJoueur() {
        return nomJoueur;
    }

    public void setNomJoueur(String nomJoueur) {
        this.nomJoueur = nomJoueur;
    }

    public String getPoste() {
        return poste;
    }

    public void setPoste(String poste) {
        this.poste = poste;
    }

    public EquipeJPA getEquipe() {
        return equipe;
    }

    public void setEquipe(EquipeJPA equipe) {
        this.equipe = equipe;
    }

    @Override
    public String toString() {
        return "JoueurJPA{" +
                "idJoueur=" + idJoueur +
                ", nomJoueur='" + nomJoueur + '\'' +
                ", poste='" + poste + '\'' +
                ", equipe=" + (equipe != null ? equipe.getNomEquipe() : "null") +
                '}';
    }
}

