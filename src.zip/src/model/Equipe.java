package model;

public class Equipe {

    private int    idEquipe;
    private String nomEquipe;

    public Equipe() {}

    public Equipe(int idEquipe, String nomEquipe) {
        this.idEquipe  = idEquipe;
        this.nomEquipe = nomEquipe;
    }

    public Equipe(String nomEquipe) {
        this.nomEquipe = nomEquipe;
    }

    // Getters & Setters
    public int getIdEquipe() { return idEquipe; }
    public void setIdEquipe(int idEquipe) { this.idEquipe = idEquipe; }

    public String getNomEquipe() { return nomEquipe; }
    public void setNomEquipe(String nomEquipe) { this.nomEquipe = nomEquipe; }

    @Override
    public String toString() {
        return "Equipe{idEquipe=" + idEquipe + ", nomEquipe='" + nomEquipe + "'}";
    }
}
