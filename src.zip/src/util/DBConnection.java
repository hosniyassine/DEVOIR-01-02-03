package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe utilitaire pour la connexion JDBC à MySQL.
 * Modifiez les constantes URL, USER et PASSWORD selon votre configuration.
 */
public class DBConnection {

    // ── À adapter selon votre environnement ──────────────────────────────────
    private static final String URL      = "jdbc:mysql://localhost:3306/gestion_equipe_joueur"
                                           + "?useSSL=false&serverTimezone=UTC&characterEncoding=UTF-8";
    private static final String USER     = "root";
    private static final String PASSWORD = "";          
    // ─────────────────────────────────────────────────────────────────────────

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new RuntimeException("Driver MySQL introuvable : " + e.getMessage(), e);
        }
    }

    /**
     * Retourne une nouvelle connexion à la base de données.
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    /**
     * Ferme une connexion en silence (ignore les exceptions).
     */
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try { conn.close(); } catch (SQLException ignored) {}
        }
    }
}
