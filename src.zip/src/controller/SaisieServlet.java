package controller;

import dao.EquipeDAO;
import dao.JoueurDAO;
import model.Equipe;
import model.Joueur;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/saisie")
public class SaisieServlet extends HttpServlet {

    private final EquipeDAO equipeDAO = new EquipeDAO();
    private final JoueurDAO joueurDAO = new JoueurDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        try {
            List<Equipe> equipes = equipeDAO.listerEquipes();
            List<Joueur> joueurs = joueurDAO.listerJoueurs();
            req.setAttribute("equipes", equipes);
            req.setAttribute("joueurs", joueurs);
            req.getRequestDispatcher("/saisie.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException("Erreur base de données : " + e.getMessage(), e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String type = req.getParameter("type");

        try {
            if ("equipe".equals(type)) {
                traiterAjoutEquipe(req, resp);
            } else if ("joueur".equals(type)) {
                traiterAjoutJoueur(req, resp);
            } else {
                resp.sendRedirect(req.getContextPath() + "/saisie");
            }
        } catch (SQLException e) {
            throw new ServletException("Erreur base de données : " + e.getMessage(), e);
        }
    }

    private void traiterAjoutEquipe(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, ServletException, IOException {
        String nomEquipe = req.getParameter("nomEquipe");
        Equipe equipeCree = null;
        if (nomEquipe != null && !nomEquipe.trim().isEmpty()) {
            equipeCree = equipeDAO.ajouterEquipe(new Equipe(nomEquipe.trim()));
        }

        List<Equipe> equipes = equipeDAO.listerEquipes();
        List<Joueur> joueurs = joueurDAO.listerJoueurs();
        req.setAttribute("equipes", equipes);
        req.setAttribute("joueurs", joueurs);
        req.setAttribute("equipeCree", equipeCree);
        req.getRequestDispatcher("/saisie.jsp").forward(req, resp);
    }

    private void traiterAjoutJoueur(HttpServletRequest req, HttpServletResponse resp)
            throws SQLException, ServletException, IOException {
        String nom      = req.getParameter("nomJoueur");
        String poste    = req.getParameter("poste");
        String idEquipeParam = req.getParameter("idEquipe");

        Joueur joueurCree = null;
        if (nom != null && !nom.trim().isEmpty()
                && poste != null && !poste.trim().isEmpty()
                && idEquipeParam != null && !idEquipeParam.trim().isEmpty()) {

            int idEquipe = Integer.parseInt(idEquipeParam);
            joueurCree = joueurDAO.ajouterJoueur(new Joueur(nom.trim(), poste.trim(), idEquipe));
        }

        List<Equipe> equipes = equipeDAO.listerEquipes();
        List<Joueur> joueurs = joueurDAO.listerJoueurs();
        req.setAttribute("equipes", equipes);
        req.setAttribute("joueurs", joueurs);
        req.setAttribute("joueurCree", joueurCree);
        req.getRequestDispatcher("/saisie.jsp").forward(req, resp);
    }
}

