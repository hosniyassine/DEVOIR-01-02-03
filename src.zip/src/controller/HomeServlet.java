package controller;

import dao.EquipeDAO;
import dao.JoueurDAO;
import model.Equipe;
import model.Joueur;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/home")
public class HomeServlet extends HttpServlet {

    private final EquipeDAO equipeDAO = new EquipeDAO();
    private final JoueurDAO joueurDAO = new JoueurDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        String keywordJoueur = req.getParameter("keywordJoueur");
        String keywordEquipe = req.getParameter("keywordEquipe");
        if (keywordJoueur == null) keywordJoueur = "";
        if (keywordEquipe == null) keywordEquipe = "";

        try {
            // Suppression via Home (GET + confirmation.jsp)
            if ("deleteEquipe".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                equipeDAO.supprimerEquipe(id);
                resp.sendRedirect(req.getContextPath() + "/home");
                return;
            } else if ("deleteJoueur".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                joueurDAO.supprimerJoueur(id);
                resp.sendRedirect(req.getContextPath() + "/home");
                return;
            }

            List<Equipe> equipes;
            if (keywordEquipe.trim().isEmpty()) {
                equipes = equipeDAO.listerEquipes();
            } else {
                equipes = equipeDAO.trouverParNom(keywordEquipe.trim());
            }

            List<Joueur> joueurs;

            if (keywordJoueur.trim().isEmpty()) {
                joueurs = joueurDAO.listerJoueurs();
            } else {
                joueurs = joueurDAO.trouverParNom(keywordJoueur.trim());
            }

            req.setAttribute("equipes", equipes);
            req.setAttribute("joueurs", joueurs);
            req.setAttribute("keywordJoueur", keywordJoueur);
            req.setAttribute("keywordEquipe", keywordEquipe);

            // Préparation édition inline
            if ("editEquipe".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                Equipe equipeEdit = equipeDAO.trouverParId(id);
                req.setAttribute("equipeEdit", equipeEdit);
            } else if ("editJoueur".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                Joueur joueurEdit = joueurDAO.trouverParId(id);
                req.setAttribute("joueurEdit", joueurEdit);
            }

            req.getRequestDispatcher("/home.jsp").forward(req, resp);
        } catch (SQLException e) {
            throw new ServletException("Erreur base de données : " + e.getMessage(), e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        String action = req.getParameter("action");

        try {
            if ("updateEquipe".equals(action)) {
                int id = Integer.parseInt(req.getParameter("idEquipe"));
                String nom = req.getParameter("nomEquipe");
                if (nom != null && !nom.trim().isEmpty()) {
                    Equipe equipe = new Equipe(id, nom.trim());
                    equipeDAO.modifierEquipe(equipe);
                }
            } else if ("updateJoueur".equals(action)) {
                int id = Integer.parseInt(req.getParameter("idJoueur"));
                String nom = req.getParameter("nomJoueur");
                String poste = req.getParameter("poste");
                int idEquipe = Integer.parseInt(req.getParameter("idEquipe"));
                if (nom != null && !nom.trim().isEmpty()
                        && poste != null && !poste.trim().isEmpty()) {
                    Joueur j = new Joueur(id, nom.trim(), poste.trim(), idEquipe);
                    joueurDAO.modifierJoueur(j);
                }
            }
            resp.sendRedirect(req.getContextPath() + "/home");
        } catch (SQLException e) {
            throw new ServletException("Erreur base de données : " + e.getMessage(), e);
        }
    }
}

