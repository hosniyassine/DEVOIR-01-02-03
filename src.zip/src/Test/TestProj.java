package Test;

import dao.EquipeDAO;
import dao.JoueurDAO;
import model.Equipe;
import model.Joueur;

import java.sql.SQLException;
import java.util.List;

public class TestProj {

    public static void main(String[] args) throws SQLException {

        EquipeDAO equipeDAO = new EquipeDAO();
        JoueurDAO joueurDAO = new JoueurDAO();

        List<Equipe> equipes = equipeDAO.trouverParNom("Real");
        for (Equipe e : equipes) {
            System.out.println(e.getNomEquipe());
        }

        List<Joueur> joueurs = joueurDAO.trouverParNom("Ben");
        for (Joueur j : joueurs) {
            System.out.println(j.getNomJoueur());
        }
    }
}