package Test;

import dao.EquipeJPADAO;
import dao.JoueurJPADAO;
import model.EquipeJPA;
import model.JoueurJPA;
import util.JPAUtil;

import java.util.List;

public class TestJoueurJPA {

    public static void main(String[] args) throws Exception {

        EquipeJPADAO equipeDAO = new EquipeJPADAO();
        JoueurJPADAO joueurDAO = new JoueurJPADAO();

        // S'assurer qu'il y a au moins une équipe
        if (equipeDAO.listerTous().isEmpty()) {
            equipeDAO.ajouter(new EquipeJPA("Equipe Test"));
        }

        List<EquipeJPA> equipes = equipeDAO.listerTous();
        EquipeJPA equipeRef = equipes.get(0);

        // Ajouter quelques joueurs
        joueurDAO.ajouter(new JoueurJPA("Joueur 1", "Attaquant", equipeRef));
        joueurDAO.ajouter(new JoueurJPA("Joueur 2", "Milieu", equipeRef));
        joueurDAO.ajouter(new JoueurJPA("Joueur 3", "Défenseur", equipeRef));

        // Lister tous les joueurs
        System.out.println("=== Tous les joueurs ===");
        List<JoueurJPA> tous = joueurDAO.listerTous();
        for (JoueurJPA j : tous) {
            System.out.println(j);
        }

        // Rechercher par nom
        System.out.println("=== Joueurs dont le nom contient '1' ===");
        List<JoueurJPA> filtres = joueurDAO.listerParNom("1");
        for (JoueurJPA j : filtres) {
            System.out.println(j);
        }

        // Lister par équipe
        System.out.println("=== Joueurs de l'équipe " + equipeRef.getNomEquipe() + " ===");
        List<JoueurJPA> parEquipe = joueurDAO.listerParEquipe(equipeRef);
        for (JoueurJPA j : parEquipe) {
            System.out.println(j);
        }

        // Modifier le premier joueur
        if (!tous.isEmpty()) {
            JoueurJPA j = tous.get(0);
            j.setPoste(j.getPoste() + " (modifié)");
            joueurDAO.modifier(j);
        }

        System.out.println("=== Après modifications ===");
        for (JoueurJPA j : joueurDAO.listerTous()) {
            System.out.println(j);
        }

        JPAUtil.close();
    }
}

