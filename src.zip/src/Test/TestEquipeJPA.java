package Test;

import dao.EquipeJPADAO;
import model.EquipeJPA;
import util.JPAUtil;

import java.util.List;

public class TestEquipeJPA {

    public static void main(String[] args) throws Exception {

        EquipeJPADAO dao = new EquipeJPADAO();

        // Ajouter quelques équipes
        dao.ajouter(new EquipeJPA("Real Madrid"));
        dao.ajouter(new EquipeJPA("FC Barcelone"));
        dao.ajouter(new EquipeJPA("PSG"));

        // Lister toutes les équipes
        System.out.println("=== Toutes les équipes ===");
        List<EquipeJPA> toutes = dao.listerTous();
        for (EquipeJPA e : toutes) {
            System.out.println(e);
        }

        // Rechercher par nom
        System.out.println("=== Équipes dont le nom contient 'a' ===");
        List<EquipeJPA> filtre = dao.listerParNom("a");
        for (EquipeJPA e : filtre) {
            System.out.println(e);
        }

        // Modifier la première équipe
        if (!toutes.isEmpty()) {
            EquipeJPA e = toutes.get(0);
            e.setNomEquipe(e.getNomEquipe() + " (modifié)");
            dao.modifier(e);
        }

        // Supprimer la dernière équipe
        toutes = dao.listerTous();
        if (!toutes.isEmpty()) {
            EquipeJPA e = toutes.get(toutes.size() - 1);
            dao.supprimer(e);
        }

        System.out.println("=== Après modifications ===");
        for (EquipeJPA e : dao.listerTous()) {
            System.out.println(e);
        }

        JPAUtil.close();
    }
}

